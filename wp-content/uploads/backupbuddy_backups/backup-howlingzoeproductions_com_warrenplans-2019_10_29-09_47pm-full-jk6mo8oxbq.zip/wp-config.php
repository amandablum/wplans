<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dbqcjp6gdwev54' );

/** MySQL database username */
define( 'DB_USER', 'udeyv3unte2y5' );

/** MySQL database password */
define( 'DB_PASSWORD', 'wwut5rw3a6zd' );

/** MySQL hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'kh9DoNl)+fXBy[L~vL_=XEK]5P%B=zV#I%z}`giE,lGlf+/&rCx58z_#aA*djcKE' );
define( 'SECURE_AUTH_KEY',   'qJ;IiO!m)Z(B0Q3&~3O2]P#+rLr%,af%:`r~^dGn]+9wi}Y~qzL.R{#QqOl}22lF' );
define( 'LOGGED_IN_KEY',     '1F^5q5d%c)_^YC qYe^U4.>1`:@~|T>(LY7E^RE7rLZvU} {UbFei<]C8FzPQsuO' );
define( 'NONCE_KEY',         '+TQ/7%*XB,%IhHw4K9^.3)a^7S<n_NVF>r,WVjju%:pdd*JBDEJlR9$S<{MdyORi' );
define( 'AUTH_SALT',         '=]8bp,*CVsq>_/y!ooHKg#dI7d_RPy92k8&8Y_Jtp|nJ,eH|FFCk)C=:V+$y[%&V' );
define( 'SECURE_AUTH_SALT',  '}$wD[My$5x)!j@D^CE<8yfMkWw+3?lA&=AKRyM8NP0#.#L^Q3(dc$G8}uka.]t6L' );
define( 'LOGGED_IN_SALT',    'ya[TecVv<v`04hDb`oy5C)w&xvu5Z#d1qXy8Xw)vSH=gvxVbGhDrG#ZDB&/Z*)N&' );
define( 'NONCE_SALT',        'U,Q0YtJ<s,.X(02PG[a;2K,yQ._X0+5$wb*9P*4z`eseN)]@<(`qfX<.lgPlt7XY' );
define( 'WP_CACHE_KEY_SALT', 'bS!@ >]3[mJU.SCQ-iRt<-[_;h!LQ$f1opNI+C6F`lM4z*_DNatIeHK4KB!P11TT' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
@include_once('/var/lib/sec/wp-settings.php'); // Added by SiteGround WordPress management system
